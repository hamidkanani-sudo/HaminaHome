package com.hamina.home.player

import android.os.Bundle
import androidx.activity.ComponentActivity

/**
 * Simple full-screen photo viewer with D-pad navigation between images.
 */
class PhotoViewerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Implementation coming in next iteration
        finish()
    }
}
