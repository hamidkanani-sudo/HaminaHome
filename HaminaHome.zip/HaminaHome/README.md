# Hamina Home

**Fast, lightweight media browser for Android TV**

Browse videos, photos and music stored on your Windows PC (or any SMB share) over the local network.  
Designed for speed, remote-control comfort and a clean media-center feel.

## Features implemented

- Android TV only (Leanback launcher)
- Multiple SMB servers (add / persist)
- Fast folder browsing with **local cache** of directory listings
- Left details panel (name, size, type, resume hint)
- List view with focus highlight for D-pad
- Built-in video player (Media3 / ExoPlayer)
  - Streams directly from SMB (no full download)
  - **Resume** from last position
  - Periodic position saving
  - Aspect ratio modes (FIT / FILL / STRETCH)
  - Global subtitle settings model (size, color, position, offset)
- Sort modes including **Last Played**
- Predictable Back navigation (folder → parent → server list)
- Clear network error state with Retry concept
- Completely offline after servers are configured

## Project structure

```
app/src/main/java/com/hamina/home/
├── HaminaApp.kt
├── data/
│   ├── model/Models.kt
│   ├── cache/CacheManager.kt
│   ├── smb/SmbManager.kt
│   ├── smb/SmbDataSource.kt          ← Media3 streaming from SMB
│   ├── settings/SettingsRepository.kt
│   ├── settings/ServerRepository.kt
│   └── playback/PlaybackRepository.kt
├── ui/
│   ├── MainActivity.kt
│   └── AddServerHelper.kt
└── player/
    ├── PlayerActivity.kt
    └── PhotoViewerActivity.kt        (stub)
```

## How to open in Android Studio

1. Copy the entire `HaminaHome` folder to your computer.
2. Open Android Studio → **Open** → select the `HaminaHome` folder.
3. Wait for Gradle sync (first time downloads dependencies).
4. Connect an Android TV device / emulator (or a real TV box with USB debugging / ADB).
5. Run the `app` configuration.

### First run

- The app starts on the Servers screen.
- Use the simple dialog (or call `AddServerHelper.showAddDialog`) to add your Windows share:
  - Host = IP of your PC (e.g. `192.168.1.20`)
  - Share = the shared folder name (e.g. `Videos`)
  - Username / Password if the share is protected.

## Build from command line

```bash
cd HaminaHome
./gradlew :app:assembleDebug
```

APK will be at:  
`app/build/outputs/apk/debug/app-debug.apk`

## What still can be improved (optional later)

- Full Compose form for adding/editing servers (currently a basic AlertDialog helper)
- Grid view layout
- Thumbnail generation & progressive loading
- Photo viewer
- Rename / Delete / Copy UI actions
- Subtitle style controls inside the player UI
- Better D-pad focus restoration after Back

## Tech stack

- Kotlin
- Jetpack Compose + some classic views for player
- Media3 (ExoPlayer)
- smbj (SMB2/3)
- DataStore for settings & server list & playback positions
- Coroutines

---

**Hamina Home** – your media, fast and simple on the big screen.
